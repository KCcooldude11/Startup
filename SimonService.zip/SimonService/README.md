# simon-javascript

This deliverable demonstrates the use of basic JavaScript for interactivity.
